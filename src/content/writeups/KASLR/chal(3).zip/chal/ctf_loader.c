// SPDX-License-Identifier: GPL-2.0
/*
 * ctf_loader.c
 *
 * One-shot flag sealer for the CTF VM.  Reads the plaintext flag from
 * a staging area, derives an AES-256 wrap key from kernel entropy,
 * and writes the sealed blob to disk.  The wrap key exists only for
 * the duration of this boot session  
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/firmware.h>
#include <linux/siphash.h>
#include <linux/fs.h>
#include <crypto/hash.h>
#include <crypto/skcipher.h>
#include <crypto/aes.h>

#define WRAP_KEY_LEN     32
#define NET_SECRET_LEN   sizeof(siphash_key_t)   /* 16 */
#define SEALED_PATH      "/var/lib/ctf/flag.zip"

extern siphash_key_t net_secret;   /* net/core/secure_seq.c */

static int sha256_one(const void *data, size_t len, u8 out[32])
{
        struct shash_desc *desc;
        struct crypto_shash *tfm;
        int ret;

        tfm = crypto_alloc_shash("sha256", 0, 0);
        if (IS_ERR(tfm))
                return PTR_ERR(tfm);

        desc = kzalloc(sizeof(*desc) + crypto_shash_descsize(tfm), GFP_KERNEL);
        if (!desc) {
                crypto_free_shash(tfm);
                return -ENOMEM;
        }
        desc->tfm = tfm;

        ret = crypto_shash_digest(desc, data, len, out);

        kfree_sensitive(desc);
        crypto_free_shash(tfm);
        return ret;
}

/* derive AES-256 wrap key from kernel entropy source */
static int derive_wrap_key(u8 out[WRAP_KEY_LEN])
{
        const u8 *src = (const u8 *)&net_secret;

        return sha256_one(&src, sizeof(src), out);
}

static int aes256_cbc_encrypt(const u8 *key, const u8 *in, u8 *out, size_t len)
{
        struct crypto_skcipher *tfm;
        struct skcipher_request *req;
        struct scatterlist sg_in, sg_out;
        u8 iv[AES_BLOCK_SIZE] = { 0 };
        int ret;

        tfm = crypto_alloc_skcipher("cbc(aes)", 0, 0);
        if (IS_ERR(tfm)) return PTR_ERR(tfm);

        ret = crypto_skcipher_setkey(tfm, key, WRAP_KEY_LEN);
        if (ret) goto out_tfm;

        req = skcipher_request_alloc(tfm, GFP_KERNEL);
        if (!req) { ret = -ENOMEM; goto out_tfm; }

        sg_init_one(&sg_in, in, len);
        sg_init_one(&sg_out, out, len);
        skcipher_request_set_crypt(req, &sg_in, &sg_out, len, iv);
        ret = crypto_skcipher_encrypt(req);

        skcipher_request_free(req);
out_tfm:
        crypto_free_skcipher(tfm);
        return ret;
}

static int __init ctf_loader_init(void)
{
        const struct firmware *fw;
        u8 wrap_key[WRAP_KEY_LEN];
        u8 *sealed;
        int ret;

        pr_info("ctf_loader: module loaded\n");

        ret = request_firmware(&fw, "flag_plain", NULL);
        if (ret) {
                pr_err("ctf_loader: plaintext flag not found in staging area\n");
                return ret;
        }

        pr_info("ctf_loader: deriving wrap key from kernel entropy source\n");
        ret = derive_wrap_key(wrap_key);
        if (ret) goto out_fw;

        sealed = kmalloc(fw->size, GFP_KERNEL);
        if (!sealed) { ret = -ENOMEM; goto out_fw; }

        ret = aes256_cbc_encrypt(wrap_key, fw->data, sealed, fw->size);
        if (ret) goto out_sealed;

        /* write sealed blob to disk — detail elided for brevity */
        pr_info("ctf_loader: flag sealed to %s (%zu bytes, AES-256-CBC, IV=0)\n",
                SEALED_PATH, fw->size);
        pr_info("ctf_loader: wrap key destroyed — recoverable only during this boot\n");

out_sealed:
        kfree_sensitive(sealed);
out_fw:
        memzero_explicit(wrap_key, sizeof(wrap_key));
        release_firmware(fw);
        return ret;
}

module_init(ctf_loader_init);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("CTF one-shot flag sealer");
