=== XZ_Backdoor ===
Category: Reversing / Forensics
Difficulty: ★★★★★ Expert

[ Scenario ]

During a supply chain security audit of an open-source compression library,
our team discovered suspicious modifications to the build system. The
changes closely resemble the techniques used in the XZ Utils compromise
(CVE-2024-3094), where a backdoor was hidden in release tarballs through
a modified autotools macro.

We have extracted the relevant files from the compromised release tarball.
Your mission is to trace the attack chain, extract the hidden payload,
and recover the secret.

[ Files ]

  build-to-host.m4          - Modified autotools macro (start here)
  tests/files/              - Test fixture files referenced by the build

[ Hints ]

1. In CVE-2024-3094, the backdoor payload was hidden inside test fixture
   files that appeared to be corrupted compression samples.

2. The build macro uses a specific pattern to identify which test file
   contains the payload. Look at how grep is used.

3. The extraction pipeline involves multiple stages of transformation.
   Pay attention to xz and tr commands.

4. The extracted payload targets a specific well-known network service.
   Understanding what it hooks — and what key material it uses — is
   essential to recovering the flag.

Flag format: CDDC2026{...}
