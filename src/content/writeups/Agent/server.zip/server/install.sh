#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

command -v node >/dev/null 2>&1 || { echo "Error: Node.js 18+ is required." >&2; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Error: Docker is required." >&2; exit 1; }

echo "Installing Node.js dependencies..."
npm install

cat <<'EOF'

Install complete.

This is a readable copy of the grading server. The contest server runs a HIDDEN
binary as sandbox/stage/target/chal4 (not included). Your reference binaries
chal1/chal2/chal3 are in sandbox/stage/target/. To dry-run the full pipeline
locally, copy one in as chal4, then prewarm and start:

  cp sandbox/stage/target/chal1 sandbox/stage/target/chal4   # local stand-in (fake flag)
  ./prewarm_docker_cache.sh                                  # build sandbox images once (avoids slow first run)
  INSPECT_USE_PREBUILT=1 node server.js                      # then open http://localhost:30005

Notes:
  - The web UI solves the submission proof-of-work automatically (a few minutes at
    the default difficulty). Lower it for local iteration: SUBMIT_POW_BITS=16 ...
  - The local target uses a fake flag (CDDC2026{fake_flag}); the real flag only
    exists on the contest server's hidden chal4.
EOF
