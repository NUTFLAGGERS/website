#!/bin/bash
set -e

SOLVE_FILE="/workspace/solve.py"
RESULT_FILE="/workspace/result.json"
TARGET_IP="${TARGET_IP:-target}"
TARGET_PORT="${TARGET_PORT:-9999}"
SOLVE_TIMEOUT="${SOLVE_TIMEOUT:-120}"

echo "=== Inspection Start ==="
echo "Time: $(date -Iseconds)"
echo "File: $SOLVE_FILE"
echo "Target: ${TARGET_IP}:${TARGET_PORT}"
echo "Solve timeout: ${SOLVE_TIMEOUT}s"

if [ ! -f "$SOLVE_FILE" ]; then
    echo '{"status":"error","passed":false,"summary":"solve.py not found"}' > "$RESULT_FILE"
    exit 1
fi

for i in $(seq 1 30); do
    if nc -z "$TARGET_IP" "$TARGET_PORT" >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

echo "=== Running solve.py ==="
EXIT_CODE=0
# Merge stdout+stderr in execution order: the participant exploits BLIND, so the
# real "last line of program output" is their only feedback oracle.
timeout "$SOLVE_TIMEOUT" python3 "$SOLVE_FILE" > /tmp/solve_stdout.txt 2>&1 || EXIT_CODE=$?
: > /tmp/solve_stderr.txt

python3 /app/write_result.py "$EXIT_CODE" "$RESULT_FILE"

echo "=== solve.py exit code: $EXIT_CODE ==="
echo "=== STDOUT ==="
cat /tmp/solve_stdout.txt 2>/dev/null || true
echo "=== STDERR ==="
cat /tmp/solve_stderr.txt 2>/dev/null || true
echo "=== Inspection Complete ==="
