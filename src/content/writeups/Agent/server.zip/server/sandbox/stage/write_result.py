#!/usr/bin/env python3
import json
import os
import sys

exit_code = int(sys.argv[1])
result_file = sys.argv[2]

def read_file(path):
    if not os.path.exists(path):
        return ""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

stdout = read_file("/tmp/solve_stdout.txt")
stderr = read_file("/tmp/solve_stderr.txt")
passed = exit_code == 0
summary = (
    "solve.py executed successfully (exit code 0)"
    if passed
    else f"solve.py failed (exit code {exit_code})"
)

result = {
    "status": "passed" if passed else "failed",
    "passed": passed,
    "summary": summary,
    "exit_code": exit_code,
    "stdout": stdout,
    "stderr": stderr,
}

with open(result_file, "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print(f"Result written: {'PASS' if passed else 'FAIL'}")
