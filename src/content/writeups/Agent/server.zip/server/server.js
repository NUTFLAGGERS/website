// CDDC2026 — slim submission/validation server.
// Flow: upload solve.py -> static (+optional AI) safety check -> docker sandbox
//       run vs the hidden target -> return the LAST line of the run output.
// Stability stack kept for ~400 participants: inspect queue + concurrency cap,
// per-submission docker sandbox, per-IP rate limiting, upload filters.
// No auth / admin / audit / sessions (intentionally removed).

const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { execFile } = require('child_process');
const multer = require('multer');
const helmet = require('helmet');

const app = express();

// Reverse-proxy awareness. Behind a proxy/ALB, the TCP peer is the proxy, so the
// real client IP must come from X-Forwarded-For — but ONLY as many hops as we
// actually trust (else clients spoof XFF to dodge the per-IP limits).
//   TRUST_PROXY unset/empty -> trust nothing (direct connections; use peer IP)
//   TRUST_PROXY=1            -> trust 1 hop (e.g. one nginx in front)
//   TRUST_PROXY=2            -> trust 2 hops (e.g. ALB -> nginx)
//   TRUST_PROXY=10.0.0.0/8,172.16.0.0/12  -> trust these proxy subnets (most robust)
function parseTrustProxy(v) {
  if (v === undefined || v === '') return false;
  if (v === 'true') return true;
  if (/^\d+$/.test(v.trim())) return Number(v.trim());
  return v.split(',').map(s => s.trim()).filter(Boolean);
}
app.set('trust proxy', parseTrustProxy(process.env.TRUST_PROXY));
const PORT = Number(process.env.PORT || 30005);
const HOST = process.env.HOST || '0.0.0.0';
const BODY_LIMIT = '64kb';
const MAX_INSPECT_JOBS = Math.max(1, Number(process.env.MAX_INSPECT_JOBS || 4));
const MAX_INSPECT_QUEUE = Math.max(1, Number(process.env.MAX_INSPECT_QUEUE || 400));
const UPLOAD_WINDOW_MS = Number(process.env.UPLOAD_WINDOW_MS || 60000);
const ACTIVE_STATES = new Set(['received', 'queued', 'running']);
const GLOBAL_WINDOW_MS = 60000;
const GLOBAL_MAX = Number(process.env.REQ_RATE_MAX || 240);
const AI_REVIEW = process.env.CODE_AI_REVIEW === '1';
// Per-IP rate limiting (1/min + one-in-flight + global per-IP cap).
// OFF by default: at the venue all participants are NAT'd to a single source IP,
// so IP-based limits would throttle everyone at once. Turn on with IP_RATE_LIMIT=1
// only when clients are distinguishable (distinct IPs, or a per-seat identity).
const IP_RATE_LIMIT = process.env.IP_RATE_LIMIT === '1';

// ── Submission proof-of-work ──
// CLIENT-paid PoW required to create a submission. Because the work is done by the
// participant (browser/tool), this throttles per-participant submissions even when
// everyone shares one NAT IP — the NAT-proof alternative to per-IP limits.
const SUBMIT_POW = process.env.SUBMIT_POW !== '0';                       // on by default
const SUBMIT_POW_BITS = Math.max(1, Number(process.env.SUBMIT_POW_BITS || 28));
const POW_TTL_MS = Number(process.env.SUBMIT_POW_TTL_MS || 60 * 60 * 1000);  // must exceed worst-case solve time (raise for high SUBMIT_POW_BITS)
// Persist the PoW signing secret so a server restart does NOT invalidate the
// challenges participants are currently solving (a 28-bit PoW takes ~10-15 min).
const POW_SECRET = (function () {
  if (process.env.POW_SECRET) return process.env.POW_SECRET;
  const f = path.join(process.env.DATA_DIR || __dirname, '.pow_secret');
  try { const s = fs.readFileSync(f, 'utf8').trim(); if (s) return s; } catch (_) {}
  const s = crypto.randomBytes(32).toString('hex');
  try { fs.writeFileSync(f, s, { mode: 0o600 }); } catch (_) {}
  return s;
})();
const usedPow = new Map();                                              // challenge -> exp (single-use)
setInterval(() => { const now = Date.now(); for (const [k, v] of usedPow) if (now > v) usedPow.delete(k); }, 60000);

function powSig(challenge, exp, bits) {
  return crypto.createHmac('sha256', POW_SECRET).update(`${challenge}.${exp}.${bits}`).digest('hex');
}
function issuePow() {
  const challenge = crypto.randomBytes(12).toString('hex');
  const bits = SUBMIT_POW_BITS;
  const exp = Date.now() + POW_TTL_MS;
  return { challenge, bits, exp, sig: powSig(challenge, exp, bits) };
}
function leadingZeroBits(buf) {
  let c = 0;
  for (const b of buf) { if (b === 0) { c += 8; continue; } let v = b; while ((v & 0x80) === 0) { c++; v <<= 1; } break; }
  return c;
}
function verifyPow(h) {
  if (!SUBMIT_POW) return { ok: true };
  const challenge = String(h['x-pow-challenge'] || '');
  const exp = Number(h['x-pow-exp'] || 0);
  const bits = Number(h['x-pow-bits'] || 0);
  const nonce = String(h['x-pow-nonce'] || '');
  const sig = String(h['x-pow-sig'] || '');
  if (!challenge || !nonce || !sig || !exp || bits !== SUBMIT_POW_BITS) return { ok: false, err: 'proof-of-work required' };
  if (Date.now() > exp) return { ok: false, err: 'proof-of-work expired — get a new challenge' };
  const expect = powSig(challenge, exp, bits);
  if (sig.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expect))) return { ok: false, err: 'bad proof-of-work signature' };
  if (usedPow.has(challenge)) return { ok: false, err: 'proof-of-work already used — get a new challenge' };
  const dig = crypto.createHash('sha256').update(`${challenge}.${nonce}`).digest();
  if (leadingZeroBits(dig) < bits) return { ok: false, err: 'proof-of-work does not meet difficulty' };
  usedPow.set(challenge, exp);
  return { ok: true };
}

const __dir = __dirname;
// Runtime writables (db.json + uploaded scripts). In docker, set DATA_DIR to a
// writable named volume (e.g. /data) so the container doesn't need write perms on
// the host-mounted project dir. Defaults to the project dir for direct `node` runs.
const DATA_DIR = process.env.DATA_DIR || __dir;
const DB_PATH = path.join(DATA_DIR, 'db.json');
const SANDBOX_DIR = path.join(__dir, 'sandbox');   // must stay in the bind-mounted project (host path for nested compose)
const INSPECT_CONF_PATH = path.join(__dir, 'inspect_config.json');
const STATIC_RULES_PATH = path.join(__dir, 'code_inspector', 'static_rules.json');
const AI_PROMPT_PATH = path.join(__dir, 'code_inspector', 'ai_prompt.txt');
const KEY_FILE_PATH = path.join(__dir, 'key.txt');
const SUBMISSIONS_DIR = path.join(DATA_DIR, 'submissions');

const C = { r: '\x1b[0m', d: '\x1b[2m', g: '\x1b[32m', y: '\x1b[33m', red: '\x1b[31m', c: '\x1b[36m', m: '\x1b[35m' };
function ts() { return new Date().toLocaleTimeString('ko-KR', { hour12: false }); }
function log(s) { console.log(`  ${C.d}${ts()}${C.r} ${s}`); }

// ── tiny JSON DB (submissions only) ──
function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }
  catch (_) { return { submissions: [] }; }
}
function saveDB(db) { fs.writeFileSync(DB_PATH, JSON.stringify(db)); }
let db = loadDB();
if (!fs.existsSync(SUBMISSIONS_DIR)) fs.mkdirSync(SUBMISSIONS_DIR, { recursive: true });

function clientIp(req) {
  // req.ip honors the 'trust proxy' setting: with N trusted hops it returns the
  // (N+1)-th-from-right XFF entry; with a subnet list it returns the first
  // non-trusted address from the right. Spoofed leftmost XFF values are ignored.
  let ip = String(req.ip || req.socket.remoteAddress || '-').trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  if (ip === '::1') ip = '127.0.0.1';
  return ip || '-';
}

// ── rate limiting ──
const rl = new Map();
function consume(key, windowMs, max) {
  const now = Date.now();
  const cur = rl.get(key);
  if (!cur || now > cur.resetAt) { rl.set(key, { count: 1, resetAt: now + windowMs }); return true; }
  if (cur.count >= max) return false;
  cur.count += 1; return true;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of rl) if (now > v.resetAt) rl.delete(k); }, 60000);

// ── config / inspect ──
function loadInspectConfig() { return JSON.parse(fs.readFileSync(INSPECT_CONF_PATH, 'utf-8')); }

// ── static safety check ──
function runStaticCodeInspection(source) {
  const rules = JSON.parse(fs.readFileSync(STATIC_RULES_PATH, 'utf-8'));
  const violations = [];
  for (const r of (rules.deny_patterns || [])) {
    try {
      const m = source.match(new RegExp(r.pattern, r.flags || ''));
      if (m) violations.push({ id: r.id || 'rule', reason: r.reason || 'denied pattern', snippet: String(m[0]).slice(0, 120) });
    } catch (e) { violations.push({ id: 'invalid_rule', reason: `bad regex: ${e.message}`, snippet: '' }); }
  }
  return { passed: violations.length === 0, violations };
}

// ── optional AI safety check (off unless CODE_AI_REVIEW=1) ──
function loadOpenAIConfig() {
  let key = (process.env.OPENAI_API_KEY || '').trim();
  let model = (process.env.OPENAI_MODEL || '').trim();
  if ((!key || !model) && fs.existsSync(KEY_FILE_PATH)) {
    for (const line of fs.readFileSync(KEY_FILE_PATH, 'utf-8').split(/\r?\n/)) {
      const m = line.trim().match(/^([A-Z0-9_]+)\s*=\s*(.+)$/);
      if (!m) continue;
      let v = m[2].trim().replace(/^["']|["']$/g, '');
      if (!key && m[1] === 'OPENAI_API_KEY') key = v;
      if (!model && m[1] === 'OPENAI_MODEL') model = v;
    }
  }
  return { apiKey: key, model: model || 'gpt-4.1-mini' };
}
async function runAICodeInspection(source) {
  if (!AI_REVIEW) return { passed: true, reason: 'AI_DISABLED' };
  const { apiKey, model } = loadOpenAIConfig();
  if (!apiKey || !fs.existsSync(AI_PROMPT_PATH)) return { passed: true, reason: 'AI_UNAVAILABLE' };
  const prompt = fs.readFileSync(AI_PROMPT_PATH, 'utf-8');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.CODE_AI_TIMEOUT_MS || 12000));
  try {
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model, temperature: 0, response_format: { type: 'json_object' },
        messages: [{ role: 'system', content: prompt }, { role: 'user', content: source.slice(0, 20000) }]
      }),
      signal: controller.signal
    });
    const payload = await resp.json().catch(() => ({}));
    if (!resp.ok) return { passed: true, reason: 'AI_API_ERROR' }; // fail-open: don't block on AI outage
    let parsed = {}; try { parsed = JSON.parse(payload?.choices?.[0]?.message?.content || '{}'); } catch (_) {}
    const allow = String(parsed.decision || '').toUpperCase() === 'ALLOW' || parsed.allow === true;
    return allow ? { passed: true } : { passed: false, reason: String(parsed.reason || 'AI_POLICY_BLOCKED') };
  } catch (_) { return { passed: true, reason: 'AI_REQUEST_FAILED' }; }
  finally { clearTimeout(timer); }
}

// ── inspect queue (concurrency capped) ──
const inspectQueue = [];
const inspectActive = new Map();
function queuePosition(token) {
  const idx = inspectQueue.findIndex(j => j.token === token);
  return idx < 0 ? null : inspectActive.size + idx + 1;
}
function enqueue(token) {
  if (inspectActive.has(token) || inspectQueue.some(j => j.token === token)) return;
  if (inspectQueue.length >= MAX_INSPECT_QUEUE) { setSub(token, { status: 'error', verdict: 'SERVER BUSY', last_output: 'inspection queue is full, try again later' }); return; }
  inspectQueue.push({ token });
  setSub(token, { status: 'queued' });
  drain();
}
function drain() {
  while (inspectActive.size < MAX_INSPECT_JOBS && inspectQueue.length) {
    const job = inspectQueue.shift();
    inspectActive.set(job.token, true);
    runInspect(job.token, () => { inspectActive.delete(job.token); drain(); });
  }
}

// The LITERAL last line of the program's (merged stdout+stderr) output — the
// participant's blind-exploit oracle. Only terminal chrome is stripped; the line
// is otherwise shown verbatim so it is a deterministic feedback channel.
const TERM_NOISE = /terminfo|Terminal features|Consider setting TERM|_curses\.error/i;
function lastOutputLine(text) {
  const lines = String(text || '').replace(/\r/g, '').split('\n')
    .map(l => l.trimEnd()).filter(l => l.trim().length && !TERM_NOISE.test(l));
  return lines.length ? lines[lines.length - 1] : '';
}
// The status/verdict — the platform's judgement, shown SEPARATELY from the
// program's last output line.
function runVerdict(out, passed, summary) {
  if (passed) return 'PASS';
  const exit = Number(out.exit_code);
  if (exit === 124) return 'TIMED OUT';
  if (/docker|sandbox/i.test(String(summary))) return 'SANDBOX ERROR';
  if (Number.isFinite(exit) && exit !== 0) return `CRASHED (exit ${exit})`;
  return 'NO ARTIFACT';
}

function runInspect(token, done) {
  const sub = db.submissions.find(s => s.token === token);
  if (!sub) return done();
  const ref = token.slice(0, 8);
  setSub(token, { status: 'running' });
  const cfg = loadInspectConfig();
  const timeoutSec = Number(cfg.docker_timeout_seconds || 150);
  const filePath = path.join(SUBMISSIONS_DIR, sub.filename);
  const args = [path.join(__dir, 'inspector.py'), '--file', filePath, '--sandbox-dir', SANDBOX_DIR,
    '--submission-id', token, '--config', INSPECT_CONF_PATH, '--timeout', String(timeoutSec)];
  log(`${C.c}🔍${C.r} inspect #${ref} (${inspectActive.size}/${MAX_INSPECT_JOBS} active, ${inspectQueue.length} queued)`);
  execFile('python3', args, { timeout: (timeoutSec + 30) * 1000, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
    let result = {};
    try { const lines = stdout.trim().split('\n'); result = JSON.parse(lines[lines.length - 1]); }
    catch (_) { result = { passed: false, summary: err ? `ERROR: ${err.message}` : 'INSPECTOR_PARSE_ERROR' }; }
    const out = result.container_output || {};
    const passed = result.passed === true;
    const last_output = lastOutputLine(out.stdout);
    const verdict = runVerdict(out, passed, result.summary);
    setSub(token, {
      status: passed ? 'done' : (/docker|sandbox/i.test(String(result.summary || '')) ? 'error' : 'done'),
      passed, verdict, last_output
    });
    log(`${passed ? C.g + '✓' : C.red + '✗'}${C.r} result #${ref} → ${verdict}${passed ? '' : ' | last: ' + last_output.slice(0, 80)}`);
    done();
  });
}

function setSub(token, patch) {
  const sub = db.submissions.find(s => s.token === token);
  if (!sub) return;
  Object.assign(sub, patch, { updated_at: new Date().toISOString() });
  saveDB(db);
}

// ── code inspection pipeline (static -> AI -> sandbox) ──
async function runPipeline(token) {
  const sub = db.submissions.find(s => s.token === token);
  if (!sub) return;
  const ref = token.slice(0, 8);
  const source = fs.readFileSync(path.join(SUBMISSIONS_DIR, sub.filename), 'utf-8');
  const stat = runStaticCodeInspection(source);
  if (!stat.passed) {
    const v = stat.violations[0];
    setSub(token, { status: 'rejected', passed: false, verdict: `POLICY VIOLATION: ${v.reason}`, last_output: '' });
    log(`${C.red}✗${C.r} #${ref} static reject: ${v.id}`);
    return;
  }
  const ai = await runAICodeInspection(source);
  if (!ai.passed) {
    setSub(token, { status: 'rejected', passed: false, verdict: `POLICY VIOLATION: ${ai.reason}`, last_output: '' });
    log(`${C.red}✗${C.r} #${ref} AI reject`);
    return;
  }
  enqueue(token);
}

// ── middleware ──
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: BODY_LIMIT }));
app.use((req, res, next) => {
  if (IP_RATE_LIMIT && !consume('g:' + clientIp(req), GLOBAL_WINDOW_MS, GLOBAL_MAX))
    return res.status(429).json({ error: 'too many requests' });
  next();
});
// hide any stray admin/internal paths
app.use((req, res, next) => {
  const p = String(req.path || '').toLowerCase();
  if (p === '/admin' || p === '/admin.html' || p.startsWith('/admin/') || p.startsWith('/api/admin')) return res.status(404).send('Not Found');
  next();
});
app.use(express.static(path.join(__dir, 'public')));

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, SUBMISSIONS_DIR),
    filename: (req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.py`)
  }),
  limits: { fileSize: 256 * 1024, files: 1 },
  fileFilter: (req, file, cb) => cb(null, path.extname(file.originalname || '').toLowerCase() === '.py' ? true : new Error('only .py files are allowed'))
});

// ── routes ──
app.get('/api/pow', (_req, res) => res.json(SUBMIT_POW ? issuePow() : { challenge: '', bits: 0, exp: 0, sig: '' }));

app.post('/api/submit', (req, res) => {
  const ip = clientIp(req);
  const pv = verifyPow(req.headers);
  if (!pv.ok) return res.status(403).json({ error: pv.err, code: 'POW_REQUIRED' });
  if (IP_RATE_LIMIT) {
    // one in-flight submission per IP: reject while a prior one is still being graded
    if (db.submissions.some(s => s.ip === ip && ACTIVE_STATES.has(s.status))) {
      return res.status(429).json({ error: 'a previous submission from your IP is still being graded; wait for it to finish', code: 'IN_FLIGHT' });
    }
    // one submission per time window per IP
    if (!consume('u:' + ip, UPLOAD_WINDOW_MS, 1)) {
      const cur = rl.get('u:' + ip);
      const wait = cur ? Math.ceil((cur.resetAt - Date.now()) / 1000) : Math.ceil(UPLOAD_WINDOW_MS / 1000);
      res.setHeader('Retry-After', String(wait));
      return res.status(429).json({ error: `one submission per ${Math.ceil(UPLOAD_WINDOW_MS / 1000)}s`, retry_after_seconds: wait });
    }
  }
  upload.single('file')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'file is required' });
    // Unguessable capability token = the ONLY handle to this submission's result
    // (no enumerable id, so results can't be harvested by other participants).
    const token = crypto.randomBytes(16).toString('hex');
    db.submissions.push({
      token, ip, filename: req.file.filename, original_name: req.file.originalname,
      status: 'received', passed: false, verdict: '', last_output: '', created_at: new Date().toISOString()
    });
    saveDB(db);
    log(`${C.c}📄${C.r} submit #${token.slice(0, 8)} from ${ip} (${req.file.originalname})`);
    runPipeline(token).catch(e => setSub(token, { status: 'error', verdict: `PIPELINE ERROR: ${e.message}`, last_output: '' }));
    res.json({ token, status: 'received' });
  });
});

app.get('/api/result/:token', (req, res) => {
  const t = String(req.params.token || '');
  const sub = /^[0-9a-f]{32}$/.test(t) ? db.submissions.find(s => s.token === t) : null;
  if (!sub) return res.status(404).json({ error: 'not found' });
  res.json({
    status: sub.status,
    passed: !!sub.passed,
    queue_position: sub.status === 'queued' ? queuePosition(sub.token) : null,
    verdict: sub.verdict || '',           // platform judgement (PASS / POLICY VIOLATION / TIMED OUT / ...)
    last_output: sub.last_output || '',    // literal last line of program execution (blind oracle)
    updated_at: sub.updated_at || sub.created_at
  });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, active: inspectActive.size, queued: inspectQueue.length }));

app.listen(PORT, HOST, () => {
  console.log('');
  console.log(`  ${C.c}✦ CDDC2026 submission server${C.r}`);
  console.log(`  ${C.g}➜${C.r} http://localhost:${PORT}`);
  console.log(`  ${C.d}inspect concurrency: ${MAX_INSPECT_JOBS} | AI review: ${AI_REVIEW ? 'on' : 'off'} | submit PoW: ${SUBMIT_POW ? SUBMIT_POW_BITS + ' bits' : 'OFF'} | IP rate limit: ${IP_RATE_LIMIT ? 'on' : 'OFF'} | trust proxy: ${process.env.TRUST_PROXY || 'none'}${C.r}`);
  console.log('');
});
