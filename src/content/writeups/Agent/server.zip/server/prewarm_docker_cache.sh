#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAGE_DIR="${ROOT_DIR}/sandbox/stage"

TARGET_IMAGE="${TARGET_IMAGE:-cddc_target:cache}"
INSPECTOR_IMAGE="${INSPECTOR_IMAGE:-cddc_inspector:cache}"

echo "[prewarm] stage dir: ${STAGE_DIR}"
echo "[prewarm] target image: ${TARGET_IMAGE}"
echo "[prewarm] inspector image: ${INSPECTOR_IMAGE}"

cd "${STAGE_DIR}"

if docker compose version >/dev/null 2>&1; then
  TARGET_IMAGE="${TARGET_IMAGE}" INSPECTOR_IMAGE="${INSPECTOR_IMAGE}" \
    docker compose build target inspector
else
  TARGET_IMAGE="${TARGET_IMAGE}" INSPECTOR_IMAGE="${INSPECTOR_IMAGE}" \
    docker-compose build target inspector
fi

echo
echo "[prewarm] done"
echo "[prewarm] start server with prebuilt mode:"
echo "  INSPECT_USE_PREBUILT=1 TARGET_IMAGE=${TARGET_IMAGE} INSPECTOR_IMAGE=${INSPECTOR_IMAGE} node server.js"
