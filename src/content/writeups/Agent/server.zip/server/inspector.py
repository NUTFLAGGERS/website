#!/usr/bin/env python3
"""
inspector.py - Docker-based submission inspection pipeline

Flow:
  1. Read submitted solve.py
  2. Apply variable replacements from config (e.g. {HOST_IP} -> "192.168.0.7")
  3. Copy modified file into sandbox volume directory
  4. Run docker-compose up -d --build
  5. Wait for container to finish (or timeout)
  6. Collect results from container logs / result file
  7. Cleanup: docker-compose down, remove sandbox files
  8. Output JSON result to stdout (last line)
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time

def log(msg):
    """Print to stderr so it doesn't interfere with JSON output on stdout."""
    print(f"[inspector] {msg}", file=sys.stderr, flush=True)

def run_cmd(cmd, timeout=60, cwd=None):
    """Run a shell command and return (returncode, stdout, stderr)."""
    try:
        proc = subprocess.run(
            cmd, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=cwd
        )
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired:
        return -1, '', f'Command timed out after {timeout}s: {cmd}'
    except Exception as e:
        return -1, '', str(e)

def main():
    parser = argparse.ArgumentParser(description='Docker-based submission inspector')
    parser.add_argument('--file', required=True, help='Path to submitted file')
    parser.add_argument('--sandbox-dir', required=True, help='Sandbox base directory')
    parser.add_argument('--submission-id', required=True, help='Submission ID')
    parser.add_argument('--config', required=True, help='Path to inspect_config.json')
    parser.add_argument('--timeout', type=int, default=300, help='Docker timeout in seconds')
    parser.add_argument('--target-host-port', type=int, default=0, help='Optional host port to expose target:9999')
    parser.add_argument('--target-port-bind', default='127.0.0.1', help='Host interface for optional target port exposure')
    args = parser.parse_args()

    result = {
        'passed': False,
        'summary': '',
        'log': '',
        'stages': [],
        'target_host_port': args.target_host_port or None
    }

    def add_stage(name, success, detail=''):
        result['stages'].append({'name': name, 'success': success, 'detail': detail})
        log(f"{'✓' if success else '✗'} {name}: {detail[:200] if detail else 'ok'}")

    # ── Stage 1: Read submitted file ──
    try:
        with open(args.file, 'r', encoding='utf-8') as f:
            original_content = f.read()
        add_stage('read file', True, f'{len(original_content)} chars')
    except Exception as e:
        add_stage('read file', False, str(e))
        result['summary'] = f'failed to read file: {e}'
        print(json.dumps(result))
        sys.exit(0)

    # ── Stage 2: Load config & apply replacements ──
    try:
        with open(args.config, 'r', encoding='utf-8') as f:
            config = json.load(f)

        replacements = config.get('replacements', {})
        expected_flag = str(
            config.get('expected_flag', replacements.get('{FLAG}', ''))
        ).strip()
        modified_content = original_content
        applied = []
        for placeholder, value in replacements.items():
            # Never inject expected flag into submitted code.
            if placeholder == '{FLAG}':
                continue
            if placeholder in modified_content:
                modified_content = modified_content.replace(placeholder, value)
                applied.append(f'{placeholder} -> {value}')

        add_stage('apply replacements', True, f'{len(applied)} applied: {", ".join(applied) if applied else "none"}')
    except Exception as e:
        add_stage('apply replacements', False, str(e))
        result['summary'] = f'failed to load config: {e}'
        print(json.dumps(result))
        sys.exit(0)

    # ── Stage 3: Prepare sandbox directory ──
    sandbox_path = os.path.join(args.sandbox_dir, f'run_{args.submission_id}')
    volume_path = os.path.join(sandbox_path, 'volume')
    stage_template_path = os.path.join(args.sandbox_dir, 'stage')
    # The challenge binary is the authoritative copy in the stage template.
    default_chal_path = os.path.join(stage_template_path, 'target', 'chal4')

    try:
        # Clean up any existing sandbox for this submission
        if os.path.exists(sandbox_path):
            shutil.rmtree(sandbox_path)

        if not os.path.isdir(stage_template_path):
            raise FileNotFoundError(f'stage template not found: {stage_template_path}')

        # Base sandbox comes from the stage template.
        shutil.copytree(stage_template_path, sandbox_path)
        os.makedirs(volume_path, exist_ok=True)

        # Write modified solve.py to volume
        solve_path = os.path.join(volume_path, 'solve.py')
        with open(solve_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)

        # Create result.json placeholder in volume (container will write to this)
        result_path = os.path.join(volume_path, 'result.json')
        with open(result_path, 'w') as f:
            json.dump({'status': 'pending'}, f)

        # Ensure stage scripts are executable after copy.
        entrypoint_path = os.path.join(sandbox_path, 'entrypoint.sh')
        write_result_path = os.path.join(sandbox_path, 'write_result.py')
        if os.path.exists(entrypoint_path):
            os.chmod(entrypoint_path, 0o755)
        if os.path.exists(write_result_path):
            os.chmod(write_result_path, 0o755)

        # Ensure challenge binary exists in run target directory.
        target_dir = os.path.join(sandbox_path, 'target')
        chal_dst = os.path.join(target_dir, 'chal4')
        if not os.path.exists(chal_dst) and os.path.exists(default_chal_path):
            os.makedirs(target_dir, exist_ok=True)
            shutil.copy2(default_chal_path, chal_dst)
        if os.path.exists(chal_dst):
            os.chmod(chal_dst, 0o555)

        if args.target_host_port:
            bind_host = str(args.target_port_bind or '127.0.0.1').replace('"', '')
            override_path = os.path.join(sandbox_path, 'docker-compose.override.yml')
            with open(override_path, 'w', encoding='utf-8') as f:
                f.write(
                    'services:\n'
                    '  target:\n'
                    '    ports:\n'
                    f'      - "{bind_host}:{args.target_host_port}:9999"\n'
                )

        add_stage('prepare sandbox', True, f'{sandbox_path} (from stage template)')
    except Exception as e:
        add_stage('prepare sandbox', False, str(e))
        result['summary'] = f'failed to prepare sandbox: {e}'
        print(json.dumps(result))
        sys.exit(0)

    # ── Stage 4: docker compose up ──
    all_logs = []

    try:
        compose_cmd = None
        for candidate in ('docker compose', 'docker-compose'):
            c, _, _ = run_cmd(f'{candidate} version', timeout=15, cwd=sandbox_path)
            if c == 0:
                compose_cmd = candidate
                break

        if not compose_cmd:
            add_stage('docker run', False, 'docker compose command not found')
            all_logs.append('docker compose / docker-compose command not found')
            code = -1
            stdout = ''
            stderr = 'docker compose command not available'
        else:
            use_prebuilt = str(os.getenv('INSPECT_USE_PREBUILT', '0')).lower() in ('1', 'true', 'yes', 'on')
            up_flag = '--no-build' if use_prebuilt else '--build'
            up_cmd = f'{compose_cmd} up {up_flag} --abort-on-container-exit 2>&1'
            log(f"docker up: {compose_cmd} ({up_flag})")
            code, stdout, stderr = run_cmd(up_cmd, timeout=args.timeout, cwd=sandbox_path)
            all_logs.append(f"=== {up_cmd} (exit: {code}) ===\n{stdout}\n{stderr}")

            # If prebuilt mode failed because image is missing, do one build fallback.
            if use_prebuilt and code != 0:
                merged = f'{stdout}\n{stderr}'.lower()
                missing_image_signals = (
                    'needs to be built',
                    'no such image',
                    'pull access denied',
                    'repository does not exist',
                )
                if any(sig in merged for sig in missing_image_signals):
                    fallback_cmd = f'{compose_cmd} up --build --abort-on-container-exit 2>&1'
                    log('prebuilt image missing; falling back to --build')
                    f_code, f_stdout, f_stderr = run_cmd(fallback_cmd, timeout=args.timeout, cwd=sandbox_path)
                    all_logs.append(
                        f"=== fallback: {fallback_cmd} (exit: {f_code}) ===\n{f_stdout}\n{f_stderr}"
                    )
                    code, stdout, stderr = f_code, f_stdout, f_stderr

        if code == -1 and 'timed out' in stderr:
            add_stage('docker run', False, f'timeout ({args.timeout}s)')
            # Force cleanup on timeout
            run_cmd(f'{compose_cmd} down --timeout 10 2>&1' if compose_cmd else 'true',
                    timeout=30, cwd=sandbox_path)
        elif code != 0:
            # Container exited with error, but that might be expected (solve.py failed)
            add_stage('docker run', True, f'container exited (exit: {code})')
        else:
            add_stage('docker run', True, 'completed')

    except Exception as e:
        add_stage('docker run', False, str(e))
        all_logs.append(f"Docker error: {e}")

    # ── Stage 5: Collect results ──
    try:
        result_file = os.path.join(volume_path, 'result.json')
        flag_pattern = r'CDDC2026\{[^}\n]+\}'

        if os.path.exists(result_file):
            with open(result_file, 'r', encoding='utf-8') as f:
                container_result = json.load(f)

            result['summary'] = container_result.get('summary', 'No summary')
            result['container_output'] = {
                'stdout': container_result.get('stdout', ''),
                'stderr': container_result.get('stderr', ''),
                'exit_code': container_result.get('exit_code', -1)
            }
            add_stage('collect results', True, result['summary'])

            exit_code = int(result['container_output']['exit_code'])
            # Only trust stdout for flag extraction (ignore stderr/traceback).
            output_text = result['container_output']['stdout']
            found_flags = re.findall(flag_pattern, output_text)
            result['found_flags'] = found_flags
            result['expected_flag'] = expected_flag

            if not expected_flag:
                result['passed'] = False
                result['summary'] = 'expected_flag is not configured'
                add_stage('verify flag', False, 'expected_flag not set')
            elif not re.fullmatch(flag_pattern, expected_flag):
                result['passed'] = False
                result['summary'] = f'expected_flag format error: {expected_flag}'
                add_stage('verify flag', False, 'expected_flag is not in CDDC2026{} format')
            elif exit_code != 0:
                result['passed'] = False
                result['summary'] = f'solve.py abnormal exit code: {exit_code}'
                add_stage('verify flag', False, f'exit code {exit_code}')
            elif expected_flag in found_flags:
                result['passed'] = True
                result['summary'] = f'flag match: {expected_flag}'
                add_stage('verify flag', True, f'{expected_flag} matched')
            else:
                result['passed'] = False
                if found_flags:
                    result['summary'] = (
                        f'flag mismatch: expected={expected_flag}, '
                        f'found={", ".join(found_flags)}'
                    )
                else:
                    result['summary'] = (
                        f'no CDDC2026{{}} flag found in output '
                        f'(expected={expected_flag})'
                    )
                add_stage('verify flag', False, result['summary'])
        else:
            add_stage('collect results', False, 'result.json missing - container produced no result')
            add_stage('verify flag', False, 'no result file')
            result['passed'] = False
            result['summary'] = 'no result file'
    except Exception as e:
        add_stage('collect results', False, str(e))
        add_stage('verify flag', False, str(e))
        result['passed'] = False
        result['summary'] = f'failed to collect results: {e}'

    # ── Stage 6: Cleanup ──
    try:
        # Keep built images for cache hits on later submissions.
        run_cmd(
            'docker compose down --volumes --timeout 10 2>&1 || docker-compose down --volumes --timeout 10 2>&1',
            timeout=30, cwd=sandbox_path
        )

        # Remove the per-submission sandbox dir to avoid disk buildup at scale.
        # Set KEEP_SANDBOX=1 to retain it for debugging a specific run.
        if str(os.getenv('KEEP_SANDBOX', '0')).lower() not in ('1', 'true', 'yes', 'on'):
            shutil.rmtree(sandbox_path, ignore_errors=True)
            add_stage('cleanup', True, 'removed containers + sandbox (image cache kept)')
        else:
            add_stage('cleanup', True, 'removed containers (sandbox kept: KEEP_SANDBOX)')
    except Exception as e:
        add_stage('cleanup', False, str(e))

    # ── Build final log ──
    stage_log = '\n'.join([
        f"[{s['name']}] {'✓ PASS' if s['success'] else '✗ FAIL'}: {s['detail']}"
        for s in result['stages']
    ])
    result['log'] = stage_log + '\n\n' + '\n'.join(all_logs)

    if not result['summary']:
        result['summary'] = 'PASS' if result['passed'] else 'FAIL'

    # ── Output JSON (must be last line of stdout) ──
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    main()
